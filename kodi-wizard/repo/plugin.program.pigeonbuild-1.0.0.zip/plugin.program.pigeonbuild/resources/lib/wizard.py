#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Pigeon Build Wizard - Main Wizard Module
Core wizard functionality
"""

import os
import sys
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import uservar
from resources.lib import gui

ADDON = xbmcaddon.Addon()

def first_run():
    """Handle first run of the wizard"""
    message = (
        '[B]Welcome to Pigeon Build Wizard![/B]\n\n'
        'This wizard will help you set up Kodi for the ultimate streaming experience.\n\n'
        '[COLOR {}]Features:[/COLOR]\n'
        '• Pre-configured builds for Fire TV Stick\n'
        '• Optimized settings for smooth streaming\n'
        '• Easy add-on installation\n'
        '• Maintenance tools\n'
        '• Backup & restore functionality\n\n'
        'Get started by selecting "Install Fresh Build" from the main menu.'
    ).format(uservar.COLOR_ACCENT)

    gui.show_text_box('Welcome to Pigeon Build', message)

def show_builds():
    """Display available builds"""
    for build in uservar.BUILDS:
        name = '[COLOR {}]{}[/COLOR] - v{}'.format(
            uservar.COLOR_ACCENT,
            build['name'],
            build['version']
        )

        description = build['description']

        gui.add_item(
            name=name,
            mode='dobuild',
            icon=build.get('icon', 'icon.png'),
            fanart=build.get('fanart', 'fanart.png'),
            description=description,
            params={'name': build['name'], 'url': build['url']}
        )

    gui.end_of_directory()

def show_addons():
    """Display available add-ons"""
    addons = [
        {
            'name': 'The Crew',
            'url': 'repository.thecrew',
            'description': 'Popular streaming add-on with extensive content library'
        },
        {
            'name': 'The Loop',
            'url': 'plugin.video.the-loop',
            'description': 'Reliable streaming add-on with excellent Real-Debrid support'
        },
        {
            'name': 'FenLight',
            'url': 'plugin.video.fenlight',
            'description': 'Lightweight and fast streaming add-on'
        },
        {
            'name': 'Seren',
            'url': 'plugin.video.seren',
            'description': 'Premium add-on for debrid users with Trakt integration'
        }
    ]

    for addon in addons:
        name = '[COLOR {}]{}[/COLOR]'.format(uservar.COLOR_TEXT_SECONDARY, addon['name'])

        gui.add_item(
            name=name,
            mode='doaddon',
            icon='addons.png',
            fanart='fanart.png',
            description=addon['description'],
            params={'url': addon['url']}
        )

    gui.end_of_directory()

def show_advanced_settings():
    """Display advanced settings options"""
    settings_options = [
        {
            'name': 'Fire TV Stick (1GB RAM)',
            'type': 'firestick_1gb',
            'description': 'Optimized settings for Fire TV Stick with 1GB RAM'
        },
        {
            'name': 'Fire TV Stick (2GB RAM) / 4K',
            'type': 'firestick_2gb',
            'description': 'Optimized settings for Fire TV Stick 4K and newer models'
        },
        {
            'name': 'NVIDIA Shield (3GB RAM)',
            'type': 'shield_3gb',
            'description': 'Optimized settings for NVIDIA Shield TV'
        },
        {
            'name': 'PC/Desktop (4GB+ RAM)',
            'type': 'pc_4gb_plus',
            'description': 'Optimized settings for desktop computers'
        }
    ]

    for setting in settings_options:
        name = '[COLOR {}]{}[/COLOR]'.format(uservar.COLOR_TEXT_SECONDARY, setting['name'])

        gui.add_item(
            name=name,
            mode='doadvanced',
            icon='settings.png',
            fanart='fanart.png',
            description=setting['description'],
            params={'type': setting['type']}
        )

    gui.end_of_directory()

def show_maintenance():
    """Display maintenance options"""
    maintenance_options = [
        {
            'name': 'Clear Cache',
            'action': 'clearcache',
            'description': 'Clear Kodi temporary cache files'
        },
        {
            'name': 'Clear Packages',
            'action': 'clearpackages',
            'description': 'Remove downloaded addon packages'
        },
        {
            'name': 'Clear Thumbnails',
            'action': 'clearthumbs',
            'description': 'Delete all thumbnails and purge textures database'
        },
        {
            'name': 'Purge Old Databases',
            'action': 'purgedb',
            'description': 'Remove obsolete database files to free space'
        },
        {
            'name': 'Fresh Start (Nuclear Option)',
            'action': 'freshstart',
            'description': 'Reset Kodi to factory defaults - USE WITH CAUTION!'
        }
    ]

    for option in maintenance_options:
        name = '[COLOR {}]{}[/COLOR]'.format(uservar.COLOR_TEXT_SECONDARY, option['name'])

        gui.add_item(
            name=name,
            mode='domaintenance',
            icon='maintenance.png',
            fanart='fanart.png',
            description=option['description'],
            params={'action': option['action']}
        )

    gui.end_of_directory()


def do_maintenance(action):
    """Execute maintenance action"""
    from resources.lib import maintenance

    if action == 'clearcache':
        maintenance.clear_cache()
    elif action == 'clearpackages':
        maintenance.clear_packages()
    elif action == 'clearthumbs':
        maintenance.clear_thumbnails()
    elif action == 'purgedb':
        maintenance.purge_old_databases()
    elif action == 'freshstart':
        maintenance.fresh_start()
    else:
        gui.show_ok_dialog('Error', 'Unknown maintenance action: {}'.format(action))

def show_backup():
    """Display backup/restore options"""
    backup_options = [
        {
            'name': 'Create New Backup',
            'action': 'createbackup',
            'description': 'Create a complete backup of your Kodi configuration'
        },
        {
            'name': 'Restore from Backup',
            'action': 'restorebackup',
            'description': 'Restore Kodi from a previous backup'
        },
        {
            'name': 'View Backups',
            'action': 'viewbackups',
            'description': 'View details of available backups'
        },
        {
            'name': 'Delete Backup',
            'action': 'deletebackup',
            'description': 'Remove a backup to free up space'
        }
    ]

    for option in backup_options:
        name = '[COLOR {}]{}[/COLOR]'.format(uservar.COLOR_TEXT_SECONDARY, option['name'])

        gui.add_item(
            name=name,
            mode='dobackup',
            icon='backup.png',
            fanart='fanart.png',
            description=option['description'],
            params={'action': option['action']}
        )

    gui.end_of_directory()


def do_backup(action):
    """Execute backup action"""
    from resources.lib import backup

    if action == 'createbackup':
        backup.create_backup()
    elif action == 'restorebackup':
        backup.restore_backup()
    elif action == 'viewbackups':
        backup.view_backups()
    elif action == 'deletebackup':
        backup.delete_backup()
    else:
        gui.show_ok_dialog('Error', 'Unknown backup action: {}'.format(action))

def show_support():
    """Display support/contact information"""
    support_text = (
        '[B][COLOR {}]Pigeon Build Support[/COLOR][/B]\n\n'
        '[COLOR {}]GitHub:[/COLOR] https://github.com/mz1312/pigeonhole\n'
        '[COLOR {}]Issues:[/COLOR] https://github.com/mz1312/pigeonhole/issues\n\n'
        '[B]Common Issues:[/B]\n'
        '• Buffering: Try applying advanced settings for your device\n'
        '• No streams: Check your internet connection and Real-Debrid\n'
        '• Crashes: Clear cache and packages from maintenance\n\n'
        '[B]Tips:[/B]\n'
        '• Use Real-Debrid for best quality and reliability\n'
        '• Keep your builds and add-ons updated\n'
        '• Run maintenance tools monthly\n'
    ).format(uservar.COLOR_ACCENT, uservar.COLOR_TEXT_SECONDARY, uservar.COLOR_TEXT_SECONDARY)

    gui.show_text_box('Support & Help', support_text)

def install_build(build_name):
    """Install a selected build"""
    from resources.lib import downloader
    from resources.lib import maintenance
    from resources.lib import backup
    import os
    import shutil

    # Find the build in the list
    build = None
    for b in uservar.BUILDS:
        if b['name'] == build_name:
            build = b
            break

    if not build:
        gui.show_ok_dialog('Error', 'Build not found')
        return

    # Confirm installation
    confirmed = gui.show_yes_no_dialog(
        'Install Build',
        '[B]{}[/B]\n\n{}\n\n'
        'This will replace your current Kodi configuration.\n\n'
        'Create a backup first (recommended)?'.format(
            build_name,
            build.get('description', '')
        )
    )

    if not confirmed:
        return

    # Offer to create backup
    create_backup = gui.show_yes_no_dialog(
        'Create Backup?',
        'Would you like to create a backup before installing the build?\n\n'
        'Highly recommended in case you want to restore later.'
    )

    try:
        # Show progress
        progress = gui.show_progress_dialog('Installing {}'.format(build_name))
        progress.update(0, 'Starting installation...')
        xbmc.sleep(500)

        # Create backup if requested
        if create_backup:
            progress.update(5, 'Creating backup...')
            # Create backup silently (without prompts)
            backup.ensure_backup_dir()
            backup_name = backup.get_backup_name()
            backup_path = os.path.join(backup.BACKUP_DIR, backup_name)

            import zipfile
            with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(backup.USER_PATH):
                    for file in files:
                        file_path = os.path.join(root, file)
                        archive_name = os.path.relpath(file_path, backup.USER_PATH)
                        try:
                            zipf.write(file_path, archive_name)
                        except:
                            pass

            xbmc.log('[Pigeon Build] Pre-install backup created: {}'.format(backup_name), xbmc.LOGINFO)

        # Download build
        progress.update(10, 'Downloading build files...')
        xbmc.log('[Pigeon Build] Downloading build from: {}'.format(build['url']), xbmc.LOGINFO)

        temp_dir = os.path.join(uservar.ADDON_DATA, 'temp')
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)

        build_zip = os.path.join(temp_dir, 'build.zip')

        # Download the build ZIP
        download_success = downloader.download_file(build['url'], build_zip, progress)

        if not download_success:
            progress.close()
            gui.show_ok_dialog(
                'Download Failed',
                'Failed to download build files.\n\nPlease check your internet connection and try again.'
            )
            return

        # Extract build
        progress.update(40, 'Extracting build files...')
        xbmc.log('[Pigeon Build] Extracting build...', xbmc.LOGINFO)

        extract_dir = os.path.join(temp_dir, 'build_extract')
        if os.path.exists(extract_dir):
            shutil.rmtree(extract_dir)
        os.makedirs(extract_dir)

        extract_success = downloader.extract_zip(build_zip, extract_dir, progress)

        if not extract_success:
            progress.close()
            gui.show_ok_dialog(
                'Extraction Failed',
                'Failed to extract build files.\n\nThe ZIP file may be corrupted.'
            )
            return

        # Clean Kodi (fresh start without full wipe)
        progress.update(60, 'Preparing Kodi for new build...')
        xbmc.log('[Pigeon Build] Performing selective clean...', xbmc.LOGINFO)

        # Note: We're not doing a full fresh start, just cleaning what the build will replace
        # Clear cache and thumbnails
        maintenance.clear_cache()
        if os.path.exists(maintenance.THUMBNAILS_PATH):
            shutil.rmtree(maintenance.THUMBNAILS_PATH)

        # Copy build files
        progress.update(70, 'Installing build files...')
        xbmc.log('[Pigeon Build] Copying build files to Kodi...', xbmc.LOGINFO)

        # Copy files from extract directory to Kodi home
        # Exclude wizard and repository addons as per uservar.EXCLUDES
        kodi_home = os.path.join(os.path.expanduser('~'), '.kodi')

        copy_success = downloader.copy_directory(
            extract_dir,
            kodi_home,
            excludes=uservar.EXCLUDES,
            progress_dialog=progress
        )

        if not copy_success:
            progress.close()
            gui.show_ok_dialog(
                'Installation Failed',
                'Failed to copy build files.\n\nPlease check the Kodi log for details.'
            )
            return

        # Apply GUI settings if provided
        if 'gui' in build and build['gui']:
            progress.update(85, 'Applying GUI settings...')
            gui_xml_path = os.path.join(uservar.ADDON_USERDATA, 'guisettings.xml')
            gui_download = downloader.download_file(build['gui'], gui_xml_path)
            if gui_download:
                xbmc.log('[Pigeon Build] GUI settings applied', xbmc.LOGINFO)

        # Cleanup temp files
        progress.update(95, 'Cleaning up...')
        try:
            if os.path.exists(build_zip):
                os.remove(build_zip)
            if os.path.exists(extract_dir):
                shutil.rmtree(extract_dir)
        except:
            pass

        progress.update(100, 'Installation complete!')
        xbmc.sleep(1000)
        progress.close()

        # Show completion message
        gui.show_ok_dialog(
            'Installation Complete',
            '[B]{} has been installed successfully![/B]\n\n'
            'Kodi will now force close.\n'
            'Restart Kodi to enjoy your new build!'.format(build_name)
        )

        xbmc.log('[Pigeon Build] Build installation complete: {}'.format(build_name), xbmc.LOGINFO)

        xbmc.sleep(2000)

        # Force close Kodi to apply changes
        os._exit(1)

    except Exception as e:
        xbmc.log('[Pigeon Build] Build installation error: {}'.format(str(e)), xbmc.LOGERROR)
        if 'progress' in locals():
            progress.close()
        gui.show_ok_dialog(
            'Installation Error',
            'Failed to install build.\n\nError: {}\n\nCheck the Kodi log for details.'.format(str(e))
        )

def install_addon(addon_url):
    """Install a selected addon"""
    try:
        xbmc.log('[Pigeon Build] Installing addon: {}'.format(addon_url), xbmc.LOGINFO)

        # Show progress
        progress = gui.show_progress_dialog('Installing Add-on')
        progress.update(10, 'Preparing installation...')

        # Use Kodi's built-in addon installer
        xbmc.executebuiltin('InstallAddon({})'.format(addon_url))

        progress.update(50, 'Installing addon...')

        # Wait for installation to complete (monitor for up to 30 seconds)
        max_wait = 30
        waited = 0
        while waited < max_wait:
            xbmc.sleep(1000)
            waited += 1
            progress.update(50 + (waited * 50 / max_wait), 'Installing addon...')

            # Check if addon is installed (basic check)
            if waited >= 10:  # Give it at least 10 seconds
                break

        progress.update(100, 'Installation complete!')
        xbmc.sleep(500)
        progress.close()

        gui.show_notification(
            'Add-on installation initiated!',
            icon=xbmcgui.NOTIFICATION_INFO
        )

        gui.show_ok_dialog(
            'Add-on Installation',
            'Add-on installation has been initiated.\n\n'
            'Check the Kodi notifications for installation status.\n\n'
            'Note: Some add-ons may require additional setup or dependencies.'
        )

        xbmc.log('[Pigeon Build] Addon installation command sent: {}'.format(addon_url), xbmc.LOGINFO)

    except Exception as e:
        xbmc.log('[Pigeon Build] Addon installation error: {}'.format(str(e)), xbmc.LOGERROR)
        gui.show_ok_dialog(
            'Installation Error',
            'Failed to install add-on.\n\nError: {}'.format(str(e))
        )

def apply_advanced_settings(setting_type):
    """Apply advanced settings for device type"""
    from resources.lib import maintenance

    # Confirm application
    confirmed = gui.show_yes_no_dialog(
        'Apply Settings',
        'Apply optimized advanced settings for {}?'.format(setting_type.replace('_', ' ').title())
    )

    if not confirmed:
        return

    # Apply settings using maintenance module
    success = maintenance.apply_advanced_settings(setting_type)

    if success:
        gui.show_notification('Advanced settings applied!', icon=xbmcgui.NOTIFICATION_INFO)

        gui.show_ok_dialog(
            'Settings Applied',
            'Advanced settings have been applied.\n\nRestart Kodi for changes to take effect.'
        )
    else:
        gui.show_ok_dialog(
            'Error',
            'Failed to apply advanced settings.\n\nPlease check the Kodi log for details.'
        )
